#!/usr/bin/env node
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { parseArgs } from "node:util";
import { fileURLToPath } from "node:url";
import { RefactoredSemanticLoopController } from "./simple_semantic_loop/refactor/controller.ts";
import { LiveConsoleRenderer } from "./simple_semantic_loop/refactor/live_console.ts";
import {
  CodexAppServerRuntime,
} from "./simple_semantic_loop/refactor/runtime.ts";
import { initializeRun } from "./simple_semantic_loop/refactor/run_setup.ts";
import { authorizeRuntimeRecovery } from "./simple_semantic_loop/refactor/recovery.ts";
import {
  readObservationSummary,
  writeCheckpoint,
} from "./simple_semantic_loop/refactor/observations.ts";
import { FileLoopStore } from "./simple_semantic_loop/refactor/store.ts";
import {
  CURRENT_FORMAT_VERSION,
  type StateFile,
} from "./simple_semantic_loop/refactor/types.ts";
import {
  runDoctor,
  validateRun,
} from "./simple_semantic_loop/refactor/validation.ts";
import {
  computeRemainingRequirements,
} from "./simple_semantic_loop/refactor/workflow.ts";

const scriptDir = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(scriptDir, "..");
const { positionals, values } = parseArgs({
  allowPositionals: true,
  options: {
    topic: { type: "string" },
    objective: { type: "string" },
    acceptance: { type: "string", multiple: true },
    "work-dir": { type: "string" },
    model: { type: "string" },
    "max-rounds": { type: "string" },
    "idle-timeout-ms": { type: "string" },
    "hard-timeout-ms": { type: "string" },
    "interrupt-grace-ms": { type: "string" },
    "recovery-token": { type: "string" },
    "no-provider": { type: "boolean", default: false },
    yolo: { type: "boolean", default: false },
    quiet: { type: "boolean", default: false },
    json: { type: "boolean", default: false },
  },
});

const command = positionals[0];

try {
  switch (command) {
    case "doctor":
      await doctorCommand();
      break;
    case "init":
      initCommand();
      break;
    case "run":
      await runCommand(false);
      break;
    case "resume":
      await runCommand(true);
      break;
    case "recover-runtime":
      await recoverRuntimeCommand();
      break;
    case "status":
      statusCommand();
      break;
    case "events":
      eventsCommand();
      break;
    case "validate":
      validateCommand();
      break;
    case "render":
      renderCommand();
      break;
    case "checkpoint":
      checkpointCommand();
      break;
    case "pause":
      lifecycleCommand("PAUSED", "operator requested pause");
      break;
    case "cancel":
      lifecycleCommand("FAILED", "operator cancelled run");
      break;
    default:
      usage();
      process.exitCode = 2;
  }
} catch (error) {
  process.stderr.write(
    `ERROR: ${error instanceof Error ? error.message : String(error)}\n`,
  );
  process.exitCode = 1;
}

async function doctorCommand(): Promise<void> {
  const model = values.model ?? "gpt-5.6-sol";
  const renderer = values.quiet
    ? null
    : new LiveConsoleRenderer(process.stderr);
  const runtime = values["no-provider"]
    ? null
    : new CodexAppServerRuntime({
        sandbox: "read-only",
        onLiveEvent: renderer
          ? (event) => renderer.handle(event)
          : undefined,
      });
  const report = await runDoctor(projectRoot, runtime, model);
  renderer?.finish();
  print(report);
  if (!report.valid) process.exitCode = 1;
}

function initCommand(): void {
  if (!values.topic || !values["work-dir"]) {
    throw new Error("init requires --topic and --work-dir");
  }
  const maxRounds = values["max-rounds"]
    ? Number(values["max-rounds"])
    : undefined;
  const run = initializeRun({
    projectRoot,
    workDir: resolve(values["work-dir"]),
    topic: values.topic,
    objective: values.objective,
    acceptanceCriteria: values.acceptance,
    model: values.model,
    maxRounds,
    idleTimeoutMs: optionalPositiveInteger("idle-timeout-ms"),
    hardTimeoutMs: optionalPositiveInteger("hard-timeout-ms"),
    interruptGraceMs: optionalPositiveInteger("interrupt-grace-ms"),
  });
  const goal = new FileLoopStore(resolve(values["work-dir"]))
    .readJson<{ topic: string }>("workflow_goal.json");
  print({
    status: "initialized",
    runId: run.runId,
    workDir: resolve(values["work-dir"]),
    topic: goal.topic,
    model: run.model,
    maxRounds: run.budgets.maxRounds,
    timeoutProfiles: run.budgets.timeoutProfiles,
  });
}

async function recoverRuntimeCommand(): Promise<void> {
  if (!values["recovery-token"]) {
    throw new Error("recover-runtime requires --recovery-token");
  }
  const store = new FileLoopStore(requiredWorkDir());
  const authorization = authorizeRuntimeRecovery(store, {
    token: values["recovery-token"],
    timeoutOverride: {
      ...(optionalPositiveInteger("idle-timeout-ms") !== undefined
        ? { idleTimeoutMs: optionalPositiveInteger("idle-timeout-ms") }
        : {}),
      ...(optionalPositiveInteger("hard-timeout-ms") !== undefined
        ? { hardTimeoutMs: optionalPositiveInteger("hard-timeout-ms") }
        : {}),
      ...(optionalPositiveInteger("interrupt-grace-ms") !== undefined
        ? { interruptGraceMs: optionalPositiveInteger("interrupt-grace-ms") }
        : {}),
    },
  });
  if (authorization.status === "ALREADY_CONSUMED") {
    print(authorization);
    return;
  }
  await runCommand(false);
}

async function runCommand(resume: boolean): Promise<void> {
  const workDir = requiredWorkDir();
  const store = new FileLoopStore(workDir);
  const run = store.readRun();
  requireCurrentWritableFormat(store);
  const renderer = values.quiet
    ? null
    : new LiveConsoleRenderer(process.stderr);
  const sandbox = values.yolo ? "danger-full-access" : "read-only";
  if (values.yolo) {
    process.stderr.write(
      "WARNING: --yolo uses approvalPolicy=never and sandbox=danger-full-access for fresh Agent Turns. " +
        "Tool effects can occur before output validation; Agent output remains untrusted and only Script records are workflow authority.\n",
    );
  }
  const runtime = new CodexAppServerRuntime({
    sandbox,
    onLiveEvent: renderer
      ? (event) => renderer.handle(event)
      : undefined,
  });
  const controller = new RefactoredSemanticLoopController(
    store,
    runtime,
  );
  const outcome = await controller.run(resume);
  renderer?.finish();
  print(outcome);
  process.exitCode = outcome.workflowOutcome === "FINISHED" ? 0 : 2;
}

function statusCommand(): void {
  const store = new FileLoopStore(requiredWorkDir());
  const state = store.readState();
  print({
    run: store.readRun(),
    workflowGoal: store.readJson("workflow_goal.json"),
    state,
    remainingRequirements: computeRemainingRequirements(store, state, true),
    objects: store.readObjects(),
    observations: readObservationSummary(store),
    latestRuntimeFailure: latestRuntimeFailure(store),
    runtimeRecoveryEligible:
      state.lifecycle === "FAILED" &&
      state.failureKind === "RUNTIME_RETRY_EXHAUSTED",
  });
}

function latestRuntimeFailure(store: FileLoopStore): unknown {
  const failed = store.turnRefs()
    .map((ref) => ({ ref, turn: store.readTurn(ref) }))
    .filter(({ turn }) => turn.turnState === "RUNTIME_FAILED")
    .sort((left, right) =>
      left.turn.startedAt.localeCompare(right.turn.startedAt)
    )
    .at(-1);
  if (!failed) return null;
  return {
    turnRef: failed.ref,
    role: failed.turn.role,
    failureKind: failed.turn.runtimeFailureKind,
    outputCapture: failed.turn.outputCapture,
    providerThreadId: failed.turn.providerThreadId,
    providerTurnId: failed.turn.providerTurnId,
    runtimeRef: failed.turn.runtimeRef,
    partialOutputRef: failed.turn.partialOutputRef,
    rawOutputRef: failed.turn.rawOutputRef,
  };
}

function eventsCommand(): void {
  const store = new FileLoopStore(requiredWorkDir());
  const text = store.exists("events.jsonl")
    ? store.readText("events.jsonl")
    : "";
  if (values.json) {
    print(
      text
        .split("\n")
        .filter(Boolean)
        .map((line) => JSON.parse(line)),
    );
  } else {
    process.stdout.write(text);
  }
}

function validateCommand(): void {
  const report = validateRun(requiredWorkDir());
  print(report);
  if (!report.valid) process.exitCode = 1;
}

function renderCommand(): void {
  const store = new FileLoopStore(requiredWorkDir());
  if (!store.exists("final/report.md")) {
    throw new Error(
      "final/report.md does not exist; rendering occurs only after FINISH_WORKFLOW and Script checks",
    );
  }
  print({
    status: "already_rendered_by_controller",
    finalPath: store.absolute("final/report.md"),
  });
}

function checkpointCommand(): void {
  const store = new FileLoopStore(requiredWorkDir());
  store.acquireLock();
  try {
    requireCurrentWritableFormat(store);
    const state = store.readState();
    const checkpointRef = writeCheckpoint(
      store,
      state,
      state.reason ?? "operator requested checkpoint",
    );
    print({ status: "checkpoint_written", checkpointRef });
  } finally {
    store.releaseLock();
  }
}

function lifecycleCommand(
  lifecycle: Extract<StateFile["lifecycle"], "PAUSED" | "FAILED">,
  reason: string,
): void {
  const store = new FileLoopStore(requiredWorkDir());
  store.acquireLock();
  try {
    requireCurrentWritableFormat(store);
    const state = store.readState();
    if (state.lifecycle === "FINISHED") {
      throw new Error("completed run is immutable");
    }
    store.writeState({
      ...state,
      revision: state.revision + 1,
      lifecycle,
      reason,
      failureKind: lifecycle === "FAILED" ? "NON_RECOVERABLE" : null,
      runtimeRecovery: null,
      node: null,
    }, lifecycle === "PAUSED" ? "RUN_PAUSED" : "RUN_CANCELLED");
    store.writeJson("final/outcome.json", {
      workflowOutcome: lifecycle === "PAUSED" ? "PAUSED" : "FAILED",
      reportRef: null,
      reason,
    });
    print({ lifecycle, stateRevision: state.revision + 1, reason });
  } finally {
    store.releaseLock();
  }
}

function requireCurrentWritableFormat(store: FileLoopStore): void {
  const run = store.readRun();
  const state = store.readState();
  if (
    run.formatVersion !== CURRENT_FORMAT_VERSION ||
    state.formatVersion !== CURRENT_FORMAT_VERSION
  ) {
    throw new Error(
      `formatVersion ${run.formatVersion}/${state.formatVersion} is read-only; this command requires formatVersion ${CURRENT_FORMAT_VERSION}`,
    );
  }
}

function requiredWorkDir(): string {
  if (!values["work-dir"]) throw new Error("--work-dir is required");
  const workDir = resolve(values["work-dir"]);
  if (!existsSync(resolve(workDir, "run.json"))) {
    throw new Error(`run.json does not exist in ${workDir}; run init first`);
  }
  return workDir;
}

function optionalPositiveInteger(
  name: "idle-timeout-ms" | "hard-timeout-ms" | "interrupt-grace-ms",
): number | undefined {
  const raw = values[name];
  if (raw === undefined) return undefined;
  const value = Number(raw);
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(`--${name} must be a positive integer`);
  }
  return value;
}

function print(value: unknown): void {
  process.stdout.write(`${JSON.stringify(value, null, 2)}\n`);
}

function usage(): void {
  process.stderr.write(`Usage:
  node scripts/simple_semantic_loop.ts doctor [--model MODEL] [--no-provider] [--quiet]
  node scripts/simple_semantic_loop.ts init --topic TOPIC --work-dir DIR [--objective TEXT] [--acceptance TEXT ...] [--model MODEL] [--max-rounds N] [--idle-timeout-ms N] [--hard-timeout-ms N] [--interrupt-grace-ms N]
  node scripts/simple_semantic_loop.ts run --work-dir DIR [--yolo] [--quiet]
  node scripts/simple_semantic_loop.ts resume --work-dir DIR [--yolo] [--quiet]
  node scripts/simple_semantic_loop.ts recover-runtime --work-dir DIR --recovery-token TOKEN [--idle-timeout-ms N] [--hard-timeout-ms N] [--interrupt-grace-ms N] [--yolo] [--quiet]
  node scripts/simple_semantic_loop.ts status --work-dir DIR
  node scripts/simple_semantic_loop.ts events --work-dir DIR [--json]
  node scripts/simple_semantic_loop.ts validate --work-dir DIR
  node scripts/simple_semantic_loop.ts render --work-dir DIR
  node scripts/simple_semantic_loop.ts checkpoint --work-dir DIR
  node scripts/simple_semantic_loop.ts pause --work-dir DIR
  node scripts/simple_semantic_loop.ts cancel --work-dir DIR
`);
}
